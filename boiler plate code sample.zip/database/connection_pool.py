"""
MySQL database connection pool manager with automatic reconnection,
health checks, and context managers.
"""

from typing import Optional, Dict, Any, Generator
from contextlib import contextmanager
import threading
from functools import wraps

from sqlalchemy import create_engine, text, event, pool
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker, Session, scoped_session
from sqlalchemy.pool import Pool, QueuePool
from sqlalchemy.exc import (
    OperationalError,
    DisconnectionError,
    DatabaseError as SQLAlchemyDatabaseError,
)

from utils.log_handler import setup_logging
from utils.error_handling import DatabaseError, safe_run, retry
from utils.config import DatabaseSettings

logger = setup_logging(__name__)


class DatabaseConnectionPool:
    """
    Database connection pool manager with automatic reconnection.
    Thread-safe singleton implementation.
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        # Only initialize once
        if hasattr(self, "_initialized"):
            return

        self._engine: Optional[Engine] = None
        self._session_factory: Optional[sessionmaker] = None
        self._scoped_session: Optional[scoped_session] = None
        self._settings: Optional[DatabaseSettings] = None
        self._initialized = False

    def initialize(self, settings: DatabaseSettings) -> None:
        """
        Initialize the connection pool with settings.

        Args:
            settings: Database configuration settings
        """
        if self._initialized:
            logger.warning("Connection pool already initialized")
            return

        self._settings = settings

        try:
            # Create engine with connection pool
            self._engine = create_engine(
                settings.connection_string,
                poolclass=QueuePool,
                pool_size=settings.pool_size,
                max_overflow=settings.max_overflow,
                pool_timeout=settings.pool_timeout,
                pool_recycle=settings.pool_recycle,
                pool_pre_ping=True,  # Verify connections before using
                echo=settings.echo,
                connect_args=settings.connection_args,
            )

            # Setup event listeners
            self._setup_event_listeners()

            # Create session factory
            self._session_factory = sessionmaker(
                bind=self._engine, autocommit=False, autoflush=False
            )

            # Create scoped session for thread safety
            self._scoped_session = scoped_session(self._session_factory)

            # Test connection
            self._test_connection()

            self._initialized = True
            logger.info(
                "Database connection pool initialized",
                extra={
                    "host": settings.host,
                    "database": settings.database,
                    "pool_size": settings.pool_size,
                },
            )
        except Exception as e:
            logger.error(
                f"Failed to initialize connection pool: {str(e)}", exc_info=True
            )
            raise ConnectionError(
                "Failed to initialize database connection pool", original_exception=e
            )

    def _setup_event_listeners(self) -> None:
        """Setup SQLAlchemy event listeners for connection management."""

        @event.listens_for(self._engine, "connect")
        def receive_connect(dbapi_conn, connection_record):
            """Called when a new database connection is created."""
            logger.debug("New database connection established")

        @event.listens_for(self._engine, "checkout")
        def receive_checkout(dbapi_conn, connection_record, connection_proxy):
            """Called when a connection is retrieved from the pool."""
            pass

        @event.listens_for(self._engine, "checkin")
        def receive_checkin(dbapi_conn, connection_record):
            """Called when a connection is returned to the pool."""
            pass

        @event.listens_for(Pool, "close")
        def receive_close(dbapi_conn, connection_record):
            """Called when a connection is closed."""
            logger.debug("Database connection closed")

        @event.listens_for(Pool, "invalidate")
        def receive_invalidate(dbapi_conn, connection_record, exception):
            """Called when a connection is invalidated."""
            logger.warning(
                "Database connection invalidated",
                extra={"error": str(exception) if exception else None},
            )

    @retry(max_attempts=3, delay=1.0, exceptions=(OperationalError, DisconnectionError))
    def _test_connection(self) -> None:
        """Test database connection."""
        try:
            with self._engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            logger.info("Database connection test successful")
        except Exception as e:
            logger.error(f"Database connection test failed: {str(e)}")
            raise

    @property
    def engine(self) -> Engine:
        """Get the SQLAlchemy engine."""
        if not self._initialized:
            raise RuntimeError("Connection pool not initialized")
        return self._engine

    @property
    def session_factory(self) -> sessionmaker:
        """Get the session factory."""
        if not self._initialized:
            raise RuntimeError("Connection pool not initialized")
        return self._session_factory

    def get_session(self) -> Session:
        """
        Get a new database session.

        Returns:
            SQLAlchemy Session instance
        """
        if not self._initialized:
            raise RuntimeError("Connection pool not initialized")
        return self._scoped_session()

    @contextmanager
    def session_scope(self) -> Generator[Session, None, None]:
        """
        Context manager for database sessions with automatic commit/rollback.

        Usage:
            with db_pool.session_scope() as session:
                session.add(obj)
                # Automatically commits on success, rolls back on error

        Yields:
            SQLAlchemy Session instance
        """
        session = self.get_session()
        try:
            yield session
            session.commit()
            logger.debug("Session committed successfully")
        except Exception as e:
            session.rollback()
            logger.error(f"Session rolled back due to error: {str(e)}", exc_info=True)
            raise DatabaseError("Database operation failed", original_exception=e)
        finally:
            session.close()

    @contextmanager
    def connection_scope(self) -> Generator:
        """
        Context manager for raw database connections.

        Usage:
            with db_pool.connection_scope() as conn:
                result = conn.execute(text("SELECT * FROM table"))

        Yields:
            SQLAlchemy Connection instance
        """
        conn = self._engine.connect()
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Connection error: {str(e)}", exc_info=True)
            raise DatabaseError(
                "Database connection operation failed", original_exception=e
            )
        finally:
            conn.close()

    def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on the database connection pool.

        Returns:
            Dictionary with health status information
        """
        if not self._initialized:
            return {"status": "uninitialized", "healthy": False}

        try:
            # Test connection
            with self._engine.connect() as conn:
                result = conn.execute(text("SELECT 1"))
                result.fetchone()

            # Get pool statistics
            pool = self._engine.pool

            return {
                "status": "healthy",
                "healthy": True,
                "pool_size": pool.size(),
                "checked_in": pool.checkedin(),
                "checked_out": pool.checkedout(),
                "overflow": pool.overflow(),
                "settings": {
                    "host": self._settings.host,
                    "database": self._settings.database,
                    "pool_size": self._settings.pool_size,
                    "max_overflow": self._settings.max_overflow,
                },
            }
        except Exception as e:
            logger.error(f"Health check failed: {str(e)}", exc_info=True)
            return {"status": "unhealthy", "healthy": False, "error": str(e)}

    def dispose(self) -> None:
        """Dispose of the connection pool and all connections."""
        if self._engine:
            self._engine.dispose()
            logger.info("Database connection pool disposed")

        if self._scoped_session:
            self._scoped_session.remove()

        self._initialized = False

    def __del__(self):
        """Cleanup on deletion."""
        self.dispose()


# Global instance
_connection_pool = DatabaseConnectionPool()


def initialize_db(settings: DatabaseSettings) -> None:
    """
    Initialize the global database connection pool.

    Args:
        settings: Database configuration settings
    """
    _connection_pool.initialize(settings)


def get_db_pool() -> DatabaseConnectionPool:
    """
    Get the global database connection pool instance.

    Returns:
        DatabaseConnectionPool instance
    """
    return _connection_pool


@contextmanager
def get_db_session() -> Generator[Session, None, None]:
    """
    Get a database session from the global pool.

    Usage:
        with get_db_session() as session:
            result = session.query(Model).all()

    Yields:
        SQLAlchemy Session instance
    """
    with _connection_pool.session_scope() as session:
        yield session


@contextmanager
def get_db_connection() -> Generator:
    """
    Get a raw database connection from the global pool.

    Usage:
        with get_db_connection() as conn:
            result = conn.execute(text("SELECT * FROM table"))

    Yields:
        SQLAlchemy Connection instance
    """
    with _connection_pool.connection_scope() as conn:
        yield conn


def with_db_session(func):
    """
    Decorator to inject database session into function.

    Usage:
        @with_db_session
        def my_function(session, other_args):
            result = session.query(Model).all()
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        with get_db_session() as session:
            return func(session, *args, **kwargs)

    return wrapper


# Example usage
if __name__ == "__main__":
    from utils.config import get_settings

    settings = get_settings(config_path="config.yaml")

    # Initialize connection pool
    db_settings = settings.database

    initialize_db(db_settings)

    # Method 1: Using context manager
    with get_db_session() as session:
        result = session.execute(text("SELECT 1"))
        print(f"Result: {result.fetchone()}")

    # Method 2: Using decorator
    @with_db_session
    def test_function(session):
        result = session.execute(text("SELECT 1"))
        return result.fetchone()

    print(f"Decorator result: {test_function()}")

    # Health check
    health = get_db_pool().health_check()
    print(f"Health check: {health}")
