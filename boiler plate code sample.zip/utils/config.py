"""
Configuration management using Pydantic BaseSettings.
Supports both environment variables and YAML configuration files.
"""

import os
from pathlib import Path
from typing import Optional, List, Dict, Any
from functools import lru_cache

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
import yaml


class DatabaseSettings(BaseSettings):
    """Database connection configuration."""

    host: str = Field(default="localhost", description="Database host")
    port: int = Field(default=3306, description="Database port")
    username: str = Field(default="fhir_user", description="Database username")
    password: str = Field(default="", description="Database password")
    database: str = Field(default="fhir_db", description="Database name")

    # Connection pool settings
    pool_size: int = Field(default=10, description="Connection pool size")
    max_overflow: int = Field(default=20, description="Max overflow connections")
    pool_timeout: int = Field(default=30, description="Pool timeout in seconds")
    pool_recycle: int = Field(default=3600, description="Connection recycle time")
    echo: bool = Field(default=False, description="Echo SQL queries")

    # Connection string template
    driver: str = Field(default="mysql+pymysql", description="SQLAlchemy driver")

    model_config = SettingsConfigDict(env_prefix="DB_", case_sensitive=False, extra="allow")

    @property
    def connection_string(self) -> str:
        """Generate SQLAlchemy connection string."""
        return (
            f"{self.driver}://{self.username}:{self.password}"
            f"@{self.host}:{self.port}/{self.database}"
        )

    @property
    def connection_args(self) -> Dict[str, Any]:
        """Additional connection arguments."""
        return {
            "charset": "utf8mb4",
            "connect_timeout": 10,
            "ssl_ca": "C:\\Users\\kkumar\\Downloads\\newcacert (1).pem",

        }


class LoggingSettings(BaseSettings):
    """Logging configuration."""

    level: str = Field(default="INFO", description="Log level")
    format: str = Field(default="json", description="Log format: json or text")
    output: str = Field(default="stdout", description="Log output: stdout or file")
    file_path: Optional[str] = Field(
        default=None, description="Log file path if output=file"
    )
    max_bytes: int = Field(
        default=10485760, description="Max log file size in bytes"  # 10MB
    )
    backup_count: int = Field(default=5, description="Number of backup files")

    model_config = SettingsConfigDict(env_prefix="LOG_", case_sensitive=False)

    @field_validator("level")
    @classmethod
    def validate_level(cls, v: str) -> str:
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        v = v.upper()
        if v not in valid_levels:
            raise ValueError(f"Invalid log level. Must be one of {valid_levels}")
        return v


class ImportSettings(BaseSettings):
    """Import pipeline configuration."""

    input_directory: str = Field(
        default="./data/input", description="Input directory for FHIR bundles"
    )
    batch_size: int = Field(default=100, description="Batch size for processing")
    max_workers: int = Field(default=4, description="Max worker threads")
    max_processes: int = Field(default=2, description="Max worker processes")
    queue_type: str = Field(default="jsonl", description="Queue type: jsonl or sqlite")
    queue_path: str = Field(
        default="./data/queue", description="Path for queue storage"
    )
    validation_enabled: bool = Field(default=True, description="Enable validation")
    fail_on_validation_error: bool = Field(
        default=False, description="Stop import on validation errors"
    )

    model_config = SettingsConfigDict(env_prefix="IMPORT_", case_sensitive=False)


class ExportSettings(BaseSettings):
    """Export pipeline configuration."""

    output_directory: str = Field(
        default="./data/output", description="Output directory for FHIR bundles"
    )
    bundle_size: int = Field(default=500, description="Number of resources per bundle")
    format: str = Field(default="json", description="Output format")
    pretty_print: bool = Field(default=True, description="Pretty print JSON")
    include_metadata: bool = Field(
        default=True, description="Include metadata in exports"
    )

    model_config = SettingsConfigDict(env_prefix="EXPORT_", case_sensitive=False)


class APISettings(BaseSettings):
    """API server configuration."""

    host: str = Field(default="0.0.0.0", description="API host")
    port: int = Field(default=8000, description="API port")
    workers: int = Field(default=4, description="Number of worker processes")
    reload: bool = Field(default=False, description="Auto-reload on code changes")

    # Security
    cors_origins: List[str] = Field(default=["*"], description="Allowed CORS origins")
    api_key_enabled: bool = Field(default=False, description="Enable API key auth")
    api_keys: List[str] = Field(default=[], description="Valid API keys")

    # Rate limiting
    rate_limit_enabled: bool = Field(default=True, description="Enable rate limiting")
    rate_limit_requests: int = Field(default=100, description="Requests per window")
    rate_limit_window: int = Field(default=60, description="Window size in seconds")

    model_config = SettingsConfigDict(env_prefix="API_", case_sensitive=False)


class FHIRSettings(BaseSettings):
    """FHIR-specific configuration."""

    default_version: str = Field(default="R4", description="Default FHIR version")
    supported_versions: List[str] = Field(
        default=["R4", "R5"], description="Supported FHIR versions"
    )
    profiles_enabled: bool = Field(
        default=True, description="Enable profile validation"
    )
    active_profiles: List[str] = Field(
        default=["us-core", "hedis"], description="Active profiles"
    )
    strict_mode: bool = Field(default=False, description="Strict validation mode")

    model_config = SettingsConfigDict(env_prefix="FHIR_", case_sensitive=False)


class Settings(BaseSettings):
    """Main application settings."""

    app_name: str = Field(default="FHIR Application", description="Application name")
    environment: str = Field(default="development", description="Environment")
    debug: bool = Field(default=False, description="Debug mode")

    # Sub-configurations
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    import_config: ImportSettings = Field(default_factory=ImportSettings)
    export_config: ExportSettings = Field(default_factory=ExportSettings)
    api: APISettings = Field(default_factory=APISettings)
    fhir: FHIRSettings = Field(default_factory=FHIRSettings)

    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", case_sensitive=False, extra="allow"
    )

    @classmethod
    def from_yaml(cls, config_path: str) -> "Settings":
        """Load settings from YAML file."""
        path = Path(config_path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")

        with open(path, "r") as f:
            config_data = yaml.safe_load(f)

        return cls(**config_data)

    @classmethod
    def load(cls, config_path: Optional[str] = None) -> "Settings":
        """
        Load settings with priority:
        1. Environment variables
        2. YAML file (if provided)
        3. Default values
        """
        if config_path and Path(config_path).exists():
            # Load from YAML first, then override with env vars
            yaml_settings = cls.from_yaml(config_path)
            # Environment variables will automatically override during initialization
            return yaml_settings

        return cls()

    def to_yaml(self, output_path: str) -> None:
        """Export settings to YAML file."""
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        config_dict = self.model_dump()
        with open(path, "w") as f:
            yaml.dump(config_dict, f, default_flow_style=False)


@lru_cache()
def get_settings(config_path: Optional[str] = None) -> Settings:
    """
    Get cached settings instance.

    Args:
        config_path: Optional path to YAML config file

    Returns:
        Settings instance
    """
    config_file = config_path or os.getenv("CONFIG_FILE")
    return Settings.load(config_file)


# Example usage and helper functions
def create_default_config(output_path: str = "config.yaml") -> None:
    """Create a default configuration file."""
    settings = Settings()
    settings.to_yaml(output_path)
    print(f"Default configuration created at: {output_path}")


if __name__ == "__main__":
    # Create default config file
    # create_default_config()

    # Load and display settings
    settings = get_settings(config_path = 'config.yaml')
    print(f"Database: {settings.database.connection_string}")
    print(f"Log Level: {settings.logging.level}")
    print(f"Environment: {settings.environment}")
    print(settings)

