"""
Simplified error handling for FHIR_APP.
Keeps custom exceptions and meaningful messages, but removes unnecessary complexity.
"""

import logging
import time
from enum import Enum
from typing import Optional, Dict, Any, Callable, Type, Tuple


# ------------------------------------------------------------------------------
# Logger Setup
# ------------------------------------------------------------------------------
logger = logging.getLogger("FHIR_APP")
if not logger.handlers:  # Prevent duplicate handlers in repeated imports
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(filename)s:%(lineno)d | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


# ------------------------------------------------------------------------------
# Error Severity Enum
# ------------------------------------------------------------------------------
class ErrorSeverity(str, Enum):
    """Defines the severity level for application errors."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# ------------------------------------------------------------------------------
# Base Custom Error
# ------------------------------------------------------------------------------
class FHIRAppError(Exception):
    """Base exception for all FHIR application errors."""

    def __init__(
        self,
        message: str,
        severity: ErrorSeverity = ErrorSeverity.MEDIUM,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.message = message
        self.severity = severity
        self.details = details or {}

    def to_dict(self) -> Dict[str, Any]:
        """Return a structured error dictionary."""
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "severity": self.severity.value,
            "details": self.details,
        }

    def __str__(self):
        return f"[{self.severity.value.upper()}] {self.__class__.__name__}: {self.message}"


# ------------------------------------------------------------------------------
# Specific Error Types
# ------------------------------------------------------------------------------
class ConfigurationError(FHIRAppError): ...
class DatabaseError(FHIRAppError): ...
class ValidationError(FHIRAppError): ...
class APIError(FHIRAppError): ...
class AuthenticationError(APIError): ...
class AuthorizationError(APIError): ...
class ResourceNotFoundError(FHIRAppError): ...


# ------------------------------------------------------------------------------
# Utility Decorators
# ------------------------------------------------------------------------------
def safe_run(
    default: Any = None,
    log_level: str = "error",
    reraise: bool = False
) -> Callable:
    """
    Decorator for lightweight error handling.
    Logs and optionally suppresses exceptions.

    Args:
        default: Value to return if an exception is suppressed.
        log_level: Logging level (e.g. "error", "warning", "info").
        reraise: If True, re-raises the exception instead of suppressing it.
    """

    def decorator(func: Callable):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)

            except FHIRAppError as e:
                log_func = getattr(logger, log_level, logger.error)
                log_func(f"{func.__name__} failed: {e}", extra={"error": e.to_dict()})
                if reraise:
                    raise
                return default

            except Exception as e:
                logger.exception(f"Unexpected error in {func.__name__}: {e}")
                if reraise:
                    raise
                return default

        return wrapper

    return decorator


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    exceptions: Tuple[Type[BaseException], ...] = (Exception,)
) -> Callable:
    """
    Simple retry decorator for transient or recoverable errors.

    Args:
        max_attempts: Number of retry attempts.
        delay: Delay in seconds between attempts.
        exceptions: Exception types to trigger retry.
    """

    def decorator(func: Callable):
        def wrapper(*args, **kwargs):
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)

                except exceptions as e:
                    if attempt < max_attempts:
                        logger.warning(
                            f"{func.__name__} attempt {attempt}/{max_attempts} failed: {e} — "
                            f"retrying in {delay}s"
                        )
                        time.sleep(delay)
                    else:
                        logger.error(f"{func.__name__} failed after {attempt} attempts: {e}")
                        raise
            return None

        return wrapper

    return decorator


# ------------------------------------------------------------------------------
# Example Usage
# ------------------------------------------------------------------------------
if __name__ == "__main__":

    @retry(max_attempts=3, delay=0.5, exceptions=(DatabaseError,))
    @safe_run(default="no_data")
    def fetch_from_db():
        """Simulate a DB call that fails."""
        x = 10 / 0
        raise DatabaseError("Database connection timeout", severity=ErrorSeverity.HIGH)

    @safe_run(default="invalid", log_level="warning")
    def validate_patient():
        """Simulate a validation error."""
        raise ValidationError("Invalid patient record", details={"resource_type": "Patient"})

    @safe_run()
    def get_resource():
        """Simulate missing FHIR resource."""
        raise ResourceNotFoundError("Patient not found", severity=ErrorSeverity.LOW)

    print("\n--- Running simplified error handling demo ---")
    print("fetch_from_db():", fetch_from_db())
    print("validate_patient():", validate_patient())
    print("get_resource():", get_resource())
