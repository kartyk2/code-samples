"""
Advanced structured logging with colorized console output,
detailed file logs, and contextual correlation/user IDs.
"""

import logging
import sys
import traceback
import uuid
from pathlib import Path
from typing import Optional
from contextvars import ContextVar
from logging.handlers import RotatingFileHandler

# --- Context variables for request tracing ---
correlation_id_var: ContextVar[Optional[str]] = ContextVar(
    "correlation_id", default=None
)
user_id_var: ContextVar[Optional[str]] = ContextVar("user_id", default=None)


# --- Color support ---
class LogColors:
    RESET = "\033[0m"
    COLORS = {
        "DEBUG": "\033[36m",  # Cyan
        "INFO": "\033[32m",  # Green
        "WARNING": "\033[33m",  # Yellow
        "ERROR": "\033[31m",  # Red
        "CRITICAL": "\033[35m",  # Magenta
    }

    @staticmethod
    def colorize(level: str, message: str, use_colors: bool = True) -> str:
        if not use_colors:
            return message
        color = LogColors.COLORS.get(level, "")
        return f"{color}{message}{LogColors.RESET}"


# --- Correlation filter ---
class CorrelationFilter(logging.Filter):
    """Inject correlation and user IDs into log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.correlation_id = correlation_id_var.get() or "N/A"
        record.user_id = user_id_var.get() or "N/A"
        return True


# --- Custom formatter ---
class DetailedFormatter(logging.Formatter):
    """
    Custom text formatter with timestamps, level colors,
    correlation/user IDs, and optional exception trace.
    """

    def __init__(self, use_colors: bool = True):
        super().__init__(
            fmt="%(asctime)s | %(levelname)-8s %(name)s:%(lineno)d - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        self.use_colors = use_colors

    def format(self, record: logging.LogRecord) -> str:
        # Format base message
        message = super().format(record)
        # Add color for level
        message = LogColors.colorize(record.levelname, message, self.use_colors)

        # Add exception details if present
        if record.exc_info:
            exc_text = "".join(traceback.format_exception(*record.exc_info))
            message += f"\n{LogColors.colorize('ERROR', exc_text, self.use_colors)}"

        return message


# --- Logger setup ---
def setup_logging(
    level: str = "INFO",
    output: str = "stdout",
    file_path: Optional[str] = None,
    max_bytes: int = 10 * 1024 * 1024,
    backup_count: int = 5,
    logger_name: Optional[str] = None,
) -> logging.Logger:
    """
    Configure a logger with detailed format and level-based coloring.

    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        output: 'stdout', 'file', or 'both'
        file_path: Log file path if output includes 'file'
        max_bytes: Max size per file (default 10MB)
        backup_count: Number of rotated files to keep
        logger_name: Optional logger name
    """
    logger = logging.getLogger(logger_name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.handlers.clear()

    correlation_filter = CorrelationFilter()

    # --- Console Handler ---
    if output in ["stdout", "both"]:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(DetailedFormatter(use_colors=sys.stdout.isatty()))
        console_handler.addFilter(correlation_filter)
        logger.addHandler(console_handler)

    # --- File Handler ---
    if output in ["file", "both"]:
        if not file_path:
            raise ValueError("file_path is required when output includes 'file'.")

        Path(file_path).parent.mkdir(parents=True, exist_ok=True)

        file_handler = RotatingFileHandler(
            file_path, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8"
        )
        file_handler.setFormatter(DetailedFormatter(use_colors=False))
        file_handler.addFilter(correlation_filter)
        logger.addHandler(file_handler)

    return logger


# --- Convenience functions for context management ---
def set_correlation_id(correlation_id: Optional[str] = None) -> str:
    """Set correlation ID for current context."""
    correlation_id = correlation_id or str(uuid.uuid4())
    correlation_id_var.set(correlation_id)
    return correlation_id


def get_correlation_id() -> Optional[str]:
    return correlation_id_var.get()


def set_user_id(user_id: str) -> None:
    user_id_var.set(user_id)


def get_user_id() -> Optional[str]:
    return user_id_var.get()


def clear_context() -> None:
    correlation_id_var.set(None)
    user_id_var.set(None)


# --- Example Usage ---
if __name__ == "__main__":
    logger = setup_logging(level="DEBUG", output="both", file_path="./logs/app.log")

    set_correlation_id("test-corr-001")
    set_user_id("user-123")

    logger.debug("Debug message for developers")
    logger.info("Informational log")
    logger.warning("Something might be off")
    logger.error("Error with context", extra={"component": "auth"})
    try:
        raise ValueError("An example failure")
    except Exception:
        logger.exception("Caught an exception")
